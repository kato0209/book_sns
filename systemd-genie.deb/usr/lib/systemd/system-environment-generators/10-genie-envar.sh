#!/bin/sh
if [ -e /run/genie.env ]
then
  cat /run/genie.env
fi

